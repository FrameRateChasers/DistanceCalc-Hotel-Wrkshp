﻿Public Class Form1


    'jeffrey hagan
    'vb for business

    Const MAX_FLOOR_NUM As Integer = 8
    Const ROOMS_PER_FLOOR_NUM As Integer = 30
    Dim i As Integer = 1
    Dim intOccupancy As Integer         ' Occupancy count 
    Dim intOccupancySum As Integer   ' Total Occupancy count 
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnSave.Click


        ' validate input. makes sure input is not left empty when button is clicked
        If txtOccupancy.Text.Length <> 0 Then
            'validates and makes sure input is integer
            If Integer.TryParse(txtOccupancy.Text, intOccupancy) Then
                'validates input. makes sure input is less than or equal to 30
                If intOccupancy <= 30 Then
                    'populate list box
                    lstBox1.Items.Add("Floor Number: " & i & " Rooms Occupied: " & intOccupancy & " Occupancy Rate: " & (intOccupancy / ROOMS_PER_FLOOR_NUM) * 100 & "%")
                    'adds 1 to counter for room number
                    i += 1
                    'intOccSum is set to 0. each time button is clicked it adds occupancy from previous input
                    intOccupancySum += intOccupancy
                    'clears textbox input
                    txtOccupancy.Text = ""
                    'this will increment the floor number in combobox drop down menu
                    If cboFloors.SelectedIndex < (cboFloors.Items.Count - 1) Then
                        cboFloors.SelectedIndex = cboFloors.SelectedIndex + 1
                    Else
                        'reset combox
                        cboFloors.SelectedIndex = -1
                    End If
                    'if any validation is wrong it will display these messages               
                ElseIf intOccupancy > 30 Then
                    txtOccupancy.Text = ""
                    MsgBox("please enter a occupancy less than 30")
                End If
            Else
                txtOccupancy.Text = ""
                MsgBox("please enter whole numbers from 1-30 please")
            End If
        Else
            MsgBox("please enter a number for occupancy")
        End If

        'once the counter is greather than 8 it will do calculations which will be 

        If i = 9 Then

            Dim inthold As Integer

            inthold = intOccupancySum / (intOccupancySum / (MAX_FLOOR_NUM * ROOMS_PER_FLOOR_NUM))
            lblOccupancyRateSum.Text = inthold.ToString("p")
            lblTotalOutput.Text = intOccupancySum

        End If



    End Sub

    Private Sub btnRestart_Click(sender As Object, e As EventArgs) Handles btnRestart.Click
        lblOccupancyRateSum.Text = ""
        lblTotalOutput.Text = ""
        cboFloors.Text = -1
        txtOccupancy.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
