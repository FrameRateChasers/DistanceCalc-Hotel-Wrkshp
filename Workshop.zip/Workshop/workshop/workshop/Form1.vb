﻿Public Class Form1

    'jeffrey hagan
    'vb for business
    'workshop calculator

    Public intTotalOfAmount As Integer
    Public intRegistration As Integer
    Public NumOfDays As Integer
    Public intLodging As Integer
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click

        'error correction
        If lstListBx1.SelectedIndex = -1 Then
            MessageBox.Show("Select a workshop")
        ElseIf lstListBx2.SelectedIndex = -1 Then
            MessageBox.Show("Select a location")
        End If

        'this will clear text
        lstListBx3.Items.Clear()
        lblOutputTotal.Text = ""


        If lstListBx1.SelectedIndex = 0 Then
            intRegistration = 595
            lstListBx3.Items.Insert(0, "Registration : $" & intRegistration)
            NumOfDays = 3
        ElseIf lstListBx1.SelectedIndex = 1 Then
            intRegistration = 695
            lstListBx3.Items.Insert(0, "Registration : $" & intRegistration)
            NumOfDays = 3
        ElseIf lstListBx1.SelectedIndex = 2 Then
            intRegistration = 995
            lstListBx3.Items.Insert(0, "Registration : $" & intRegistration)
            NumOfDays = 3
        ElseIf lstListBx1.SelectedIndex = 3 Then
            intRegistration = 1295
            lstListBx3.Items.Insert(0, "Registration : $" & intRegistration)
            NumOfDays = 5
        ElseIf lstListBx1.SelectedIndex = 4 Then
            intRegistration = 395
            lstListBx3.Items.Insert(0, "Registration : $" & intRegistration)
            NumOfDays = 1
        End If

        If lstListBx2.SelectedIndex = 0 Then
            intLodging = 95 * NumOfDays
            lstListBx3.Items.Insert(0, "Lodging : $" & intLodging)
        ElseIf lstListBx2.SelectedIndex = 1 Then
            intLodging = 125 * NumOfDays
            lstListBx3.Items.Insert(0, "Lodging : $" & intLodging)
        ElseIf lstListBx2.SelectedIndex = 2 Then
            intLodging = 110 * NumOfDays
            lstListBx3.Items.Insert(0, "Lodging : $" & intLodging)
        ElseIf lstListBx2.SelectedIndex = 3 Then
            intLodging = 100 * NumOfDays
            lstListBx3.Items.Insert(0, "Lodging : $" & intLodging)
        ElseIf lstListBx2.SelectedIndex = 4 Then
            intLodging = 92 * NumOfDays
            lstListBx3.Items.Insert(0, "Lodging : $" & intLodging)
        ElseIf lstListBx2.SelectedIndex = 5 Then
            intLodging = 90 * NumOfDays
            lstListBx3.Items.Insert(0, "Lodging : $" & intLodging)

        End If





    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        intTotalOfAmount = intRegistration + intLodging
        lblOutputTotal.Text = intTotalOfAmount.ToString("c")


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'clears whats in label and listbox
        lstListBx3.Items.Clear()
        lblOutputTotal.Text = ""

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
