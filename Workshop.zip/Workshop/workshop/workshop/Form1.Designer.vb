﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lstListBx1 = New System.Windows.Forms.ListBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.lstListBx2 = New System.Windows.Forms.ListBox()
        Me.lstListBx3 = New System.Windows.Forms.ListBox()
        Me.lblOutputTotal = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstListBx1
        '
        Me.lstListBx1.FormattingEnabled = True
        Me.lstListBx1.Items.AddRange(New Object() {"HANDLING STRESS", "TIME MANAGMENT ", "SUPERVISION SKILLS", "NEGOTIATION", "HOW TO INTERVIEW"})
        Me.lstListBx1.Location = New System.Drawing.Point(12, 36)
        Me.lstListBx1.Name = "lstListBx1"
        Me.lstListBx1.Size = New System.Drawing.Size(173, 108)
        Me.lstListBx1.TabIndex = 0
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(153, 252)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(127, 50)
        Me.btnCalc.TabIndex = 1
        Me.btnCalc.Text = "CALC TOTAL"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'lstListBx2
        '
        Me.lstListBx2.FormattingEnabled = True
        Me.lstListBx2.Items.AddRange(New Object() {"AUSTIN", "CHICAGO", "DALLAS", "ORLANDO", "PHOENIX", "RALEIGH"})
        Me.lstListBx2.Location = New System.Drawing.Point(191, 36)
        Me.lstListBx2.Name = "lstListBx2"
        Me.lstListBx2.Size = New System.Drawing.Size(173, 108)
        Me.lstListBx2.TabIndex = 2
        '
        'lstListBx3
        '
        Me.lstListBx3.FormattingEnabled = True
        Me.lstListBx3.Location = New System.Drawing.Point(370, 36)
        Me.lstListBx3.Name = "lstListBx3"
        Me.lstListBx3.Size = New System.Drawing.Size(173, 108)
        Me.lstListBx3.TabIndex = 3
        '
        'lblOutputTotal
        '
        Me.lblOutputTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputTotal.Location = New System.Drawing.Point(188, 161)
        Me.lblOutputTotal.Name = "lblOutputTotal"
        Me.lblOutputTotal.Size = New System.Drawing.Size(176, 46)
        Me.lblOutputTotal.TabIndex = 4
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(286, 252)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(127, 50)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(419, 252)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(127, 50)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.Location = New System.Drawing.Point(20, 252)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(127, 50)
        Me.btnAdd.TabIndex = 8
        Me.btnAdd.Text = "ADD WORKSHOP"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(563, 314)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblOutputTotal)
        Me.Controls.Add(Me.lstListBx3)
        Me.Controls.Add(Me.lstListBx2)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lstListBx1)
        Me.Name = "Form1"
        Me.Text = "Workshop Calculator"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lstListBx1 As ListBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents lstListBx2 As ListBox
    Friend WithEvents lstListBx3 As ListBox
    Friend WithEvents lblOutputTotal As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnAdd As Button
End Class
