﻿Public Class Form1

    'Jeffrey Hagan
    'vb for business
    'distance calculator

    'declared varibles
    Dim dblSpeed As Double
    Dim dblTime As Double
    Dim dblTotal As Double
    Dim dblCount As Double
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnRun.Click

        'try catch used to stop user from entering letters
        Try
            'inputboxs open first when button is clicked and ask user for speed and time. 
            'which will only take numerical digits
            ' then multiples speed and time traveled input from user.
            ' stores them into dbltotal
            dblSpeed = CDbl(InputBox("ENTER SPEED IN MILE-PER-HOUR", "SPEED OF CAR IN MPH"))
            dblTime = CDbl(InputBox("ENTER TIME IT TRAVELED", "TIME CAR WENT IN HOURS"))
            dblTotal = dblSpeed * dblTime
        Catch
            MsgBox("PLEASE ENTER NUMBERICAL DIGITS PLEASE")
        End Try
        'once inputs are entered and valadated by try catch statement listbox is then populated
        'once populated do untill loop statement is activated
        lstListBox.Items.Add("VEHICLE SPEED:" & "" & dblSpeed)
        lstListBox.Items.Add("TIME IT TOOK TO TRAVEL:" & "" & dblTime)
        lstListBox.Items.Add("HOURS" & "     " & "DISTANCE TRAVELED")
        lstListBox.Items.Add("-----------------------------------------")
        'i(the counter) is decalred and set to 1
        'dblhold is declared, which will hold calculation
        Dim i As Double = 1
        Dim dblhold As Double
        'first in this loop it will multiple the counter and dblSpeed and store results in dblhold
        'then list box will be populated 
        'last 1 is added to the counter which changes value of counter in next iteration
        'iteration will continue untill the counter value is greater than dblTime. Once it is greater
        'iteration will end
        Do Until i > dblTime
            dblhold = i * dblSpeed
            lstListBox.Items.Add(i & "                   " & dblhold)
            i += 1
        Loop
        'listbox will be populated and show total distance traveled
        lstListBox.Items.Add("TOTAL DISTANCE:" & "     " & dblTotal)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'this will clear everything in listbox
        lstListBox.Items.Clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
